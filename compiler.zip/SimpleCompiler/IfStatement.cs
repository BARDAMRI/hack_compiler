﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SimpleCompiler
{
    public class IfStatement : StatetmentBase
    {
        public Expression Term { get; private set; }
        public List<StatetmentBase> DoIfTrue { get; private set; }
        public List<StatetmentBase> DoIfFalse { get; private set; }

        public override void Parse(TokensStack sTokens)
        {
            DoIfTrue = new List<StatetmentBase>();
            DoIfFalse = new List<StatetmentBase>();
            //check for enough tokens for if statement
            if (sTokens.Count < 7)
                throw new SyntaxErrorException("Not enough tokens for if statement", sTokens.Pop());
            Token ifS = sTokens.Pop();
            if (!(ifS is Statement) || !(((Statement)ifS).Name == "if"))
                throw new SyntaxErrorException("Missing if word in if statement", ifS);
            Token oper1 = sTokens.Pop();
            if (!(oper1 is Parentheses) || !(((Parentheses)oper1).Name == '('))
                throw new SyntaxErrorException("Missing ( in if statement", oper1);
            Term = Expression.Create(sTokens);
            Term.Parse(sTokens);
            Token oper2 = sTokens.Pop();
            if (!(oper2 is Parentheses) || !(((Parentheses)oper2).Name == ')'))
                throw new SyntaxErrorException("Missing ) in if statement", oper2);
            oper2 = sTokens.Pop();
            if (!(oper2 is Parentheses) || !(((Parentheses)oper2).Name == '{'))
                throw new SyntaxErrorException("Missing { in if statement", oper2);
            while (!(sTokens.Peek() is Parentheses && ((Parentheses)sTokens.Peek()).Name == '}'))
            {
                StatetmentBase state = Create(sTokens.Peek());
                state.Parse(sTokens);
                DoIfTrue.Add(state);
            }
            Token oper3 = sTokens.Pop();
            if (!(oper3 is Parentheses) || !(((Parentheses)oper3).Name == '}'))
                throw new SyntaxErrorException("Missing } in if statement", oper3);
            if ((sTokens.Peek() is Statement) && ((Statement)sTokens.Peek()).Name == "else")
            {
                sTokens.Pop();
                oper2 = sTokens.Pop();
                if (!(oper2 is Parentheses) || !(((Parentheses)oper2).Name == '{'))
                    throw new SyntaxErrorException("Missing { in if statement", oper2);
                while (!(sTokens.Peek() is Parentheses && ((Parentheses)sTokens.Peek()).Name == '}'))
                {
                    StatetmentBase state = Create(sTokens.Peek());
                    state.Parse(sTokens);
                    DoIfFalse.Add(state);
                }
                oper3 = sTokens.Pop();
                if (!(oper3 is Parentheses) || !(((Parentheses)oper3).Name == '}'))
                    throw new SyntaxErrorException("Missing } in if statement", oper3);
            }
        }

        public override string ToString()
        {
            string sIf = "if(" + Term + "){\n";
            foreach (StatetmentBase s in DoIfTrue)
                sIf += "\t\t\t" + s + "\n";
            sIf += "\t\t}";
            if (DoIfFalse.Count > 0)
            {
                sIf += "else{";
                foreach (StatetmentBase s in DoIfFalse)
                    sIf += "\t\t\t" + s + "\n";
                sIf += "\t\t}";
            }
            return sIf;
        }

    }
}
