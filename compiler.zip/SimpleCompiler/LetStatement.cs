﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SimpleCompiler
{
    public class LetStatement : StatetmentBase
    {
        public string Variable { get; set; }
        public Expression Value { get; set; }

        public override string ToString()
        {
            return "let " + Variable + " = " + Value + ";";
        }

        public override void Parse(TokensStack sTokens)
        {
            if (sTokens.Count < 3)
                throw new SyntaxErrorException("Not enough tokens for let statement", sTokens.Pop());
            Token let = sTokens.Pop();
            if (!(let is Statement) || ((Statement)let).Name != "let")
                throw new SyntaxErrorException("Missing let Token in let statement", let);
            Token varT = sTokens.Pop();
            if (!(sTokens.Peek() is Operator) || !(((Operator)sTokens.Peek()).Name == '='))
                throw new SyntaxErrorException("let statement error. expected: operator, recieved: " + sTokens.Peek(), sTokens.Pop());
            sTokens.Pop();
            if (!(varT is Identifier))
                throw new SyntaxErrorException("Problem with var type in let statement", varT);
            Variable = ((Identifier)varT).Name;
            Value = Expression.Create(sTokens);
            Value.Parse(sTokens);
            Token sem = sTokens.Pop();
            if (!(sem is Separator) || ((Separator)sem).Name != ';')
                throw new SyntaxErrorException("Missing semicolon in let statement", sem);
        }

    }
}
