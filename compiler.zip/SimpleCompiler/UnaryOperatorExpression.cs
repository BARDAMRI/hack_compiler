﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SimpleCompiler
{
    class UnaryOperatorExpression : Expression
    {
        public string Operator { get; set; }
        public Expression Operand { get; set; }

        public override string ToString()
        {
            return Operator + Operand;
        }

        public override void Parse(TokensStack sTokens)
        {
            if (sTokens.Count < 2)
                throw new SyntaxErrorException("Not enough tokens for unary operation",sTokens.Pop());
            if(!(sTokens.Peek() is Operator))
                throw new SyntaxErrorException("No operator in UnaryOperator", sTokens.Pop());
            Operator = ((Operator)sTokens.Pop()).Name.ToString();
            Operand = Create(sTokens);
            Operand.Parse(sTokens);


        }
    }
}
