﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SimpleCompiler
{
    public class WhileStatement : StatetmentBase
    {
        public Expression Term { get; private set; }
        public List<StatetmentBase> Body { get; private set; }

        public override void Parse(TokensStack sTokens)
        {
            Body = new List<StatetmentBase>();
            if (sTokens.Count < 7)
                throw new SyntaxErrorException("Not enough tokens for if statement", sTokens.Pop());
            //check while word
            Token whileS = sTokens.Pop();
            if (!(whileS is Statement) && ((Statement)whileS).Name == "while")
                throw new SyntaxErrorException("Missing while word in while statement", whileS);
            Token oper1 = sTokens.Pop();
            if (!(oper1 is Parentheses) || !(((Parentheses)oper1).Name == '('))
                throw new SyntaxErrorException("Missing ( in if statement", oper1);
            //checking expression
            Term = Expression.Create(sTokens);
            Term.Parse(sTokens);
            oper1 = sTokens.Pop();
            if ((!(oper1 is Parentheses)) || !(((Parentheses)oper1).Name == ')'))
                throw new SyntaxErrorException("Missing ) in if statement", oper1);
            oper1 = sTokens.Pop();
            if ((!(oper1 is Parentheses)) || !(((Parentheses)oper1).Name == '{'))
                throw new SyntaxErrorException("Missing { in if statement", oper1);
            //seeking and adding all statements to the while body
            while (!(sTokens.Peek() is Parentheses && ((Parentheses)sTokens.Peek()).Name == '}'))
            {
                StatetmentBase state = Create(sTokens.Peek());
                state.Parse(sTokens);
                Body.Add(state);
            }
            Token oper3 = sTokens.Pop();
            if (!(oper3 is Parentheses) || !(((Parentheses)oper3).Name == '}'))
                throw new SyntaxErrorException("Missing } in if statement", oper3);
        }

        public override string ToString()
        {
            string sWhile = "while(" + Term + "){\n";
            foreach (StatetmentBase s in Body)
                sWhile += "\t\t\t" + s + "\n";
            sWhile += "\t\t}";
            return sWhile;
        }

    }
}
