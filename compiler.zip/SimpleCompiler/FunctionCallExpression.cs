﻿using System;
using System.Collections.Generic;

namespace SimpleCompiler
{
    public class FunctionCallExpression : Expression
    {
        public string FunctionName { get; private set; }
        public List<Expression> Args { get; private set; }

        public override void Parse(TokensStack sTokens)
        {
            Args = new List<Expression>();
            Token tVar = sTokens.Pop();
            if (!(tVar is Identifier))
                throw new SyntaxErrorException("Expected Identifier, received " + tVar, tVar);
            FunctionName = ((Identifier)tVar).Name;
            //removing ( that close arguments list
            Token sogar = sTokens.Pop();
            if (!(sogar is Parentheses && ((Parentheses)sogar).Name == '('))
                throw new SyntaxErrorException("Missing ( in Function call", sogar);
            //adding expression list
            while (sTokens.Count > 0 && !((sTokens.Peek() is Parentheses) && (((Parentheses)sTokens.Peek()).Name == ')')))
            {
                //remove comma
                if (Args.Count > 0)
                {
                    Token comma = sTokens.Pop();
                    if (!(comma is Separator && ((Separator)comma).Name == ','))
                        throw new SyntaxErrorException("Missing comma between arguments", comma);
                }
                Expression toAdd = Create(sTokens);
                toAdd.Parse(sTokens);
                Args.Add(toAdd);

            }
            //removing ) that close arguments list
            Token tEnd = sTokens.Pop();
            if (!(tEnd is Parentheses && ((Parentheses)tEnd).Name == ')'))
                throw new SyntaxErrorException("Missing ) in FunctionCall Expression", tEnd);
        }

        public override string ToString()
        {
            string sFunction = FunctionName + "(";
            for (int i = 0; i < Args.Count - 1; i++)
                sFunction += Args[i] + ",";
            if (Args.Count > 0)
                sFunction += Args[Args.Count - 1];
            sFunction += ")";
            return sFunction;
        }
    }
}