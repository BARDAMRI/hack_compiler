﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SimpleCompiler
{
    public class Compiler
    {

        private int place;
        public Compiler()
        {
            place = 0;
        }

        public List<VarDeclaration> ParseVarDeclarations(List<string> lVarLines)
        {
            
            List<VarDeclaration> lVars = new List<VarDeclaration>();
            for (int i = 0; i < lVarLines.Count; i++)
            {
                List<Token> lTokens = Tokenize(lVarLines[i], i);
                TokensStack stack = new TokensStack(lTokens);
                VarDeclaration var = new VarDeclaration();
                var.Parse(stack);
                lVars.Add(var);
            }
            return lVars;
        }

        public List<LetStatement> ParseAssignments(List<string> lLines)
        {
            List<LetStatement> lParsed = new List<LetStatement>();
            List<Token> lTokens = Tokenize(lLines);
            TokensStack sTokens = new TokensStack();
            for (int i = lTokens.Count - 1; i >= 0; i--)
                sTokens.Push(lTokens[i]);
            while (sTokens.Count > 0)
            {
                LetStatement ls = new LetStatement();
                ls.Parse(sTokens);
                lParsed.Add(ls);

            }
            return lParsed;
        }
        public List<string> GenerateCode(LetStatement aSimple, Dictionary<string, int> dSymbolTable)
        {
            List<string> lAssembly = new List<string>();
            //add here code for computing a single let statement containing only a simple expression
            if (isNumber(aSimple.Value))
            {
                    lAssembly.AddRange(GenNumber(dSymbolTable, (NumericExpression)aSimple.Value));
            }
            else if (aSimple.Value is VariableExpression)
            {
                lAssembly.AddRange(GenVar(dSymbolTable, (VariableExpression)aSimple.Value));
            }
            else if(aSimple.Value is BinaryOperationExpression)
            {
                    lAssembly.AddRange(GenBin(dSymbolTable, (BinaryOperationExpression)aSimple.Value));
            }
            if (!dSymbolTable.ContainsKey(aSimple.Variable))
                throw new SyntaxErrorException("variable does not exists in table ", new Token());
            int ind = dSymbolTable[aSimple.Variable];
            lAssembly.Add("@" + ind);
            lAssembly.Add("D=A");
            lAssembly.Add("@LCL");
            lAssembly.Add("A=M+D");
            lAssembly.Add("D=A");//D holds the address of the variable
            lAssembly.Add("@ADDRESS");
            lAssembly.Add("M=D");//ADDRESS holds the address of the variable
            lAssembly.Add("@RESULT");
            lAssembly.Add("D=M"); //D holds the value
            lAssembly.Add("@ADDRESS");
            lAssembly.Add("A=M"); //A is the address of the variable
            lAssembly.Add("M=D"); //Put the value from D in the Adress in the memory
            return lAssembly;
        }

        private bool isNumber(Expression aSimple)
        {
            if (aSimple is NumericExpression)
                return true;
            else
                return false;
        }
        private List<string> GenNumber(Dictionary<string, int> symbolTable, NumericExpression num)
        {
            List<string> outp = new List<string>();
            int val = num.Value;
            outp.Add("@" + val);
            outp.Add("D=A");
            outp.Add("@RESULT");
            outp.Add("M=D");
            return outp;
        }
        private List<string> GenVar(Dictionary<string, int> symbolTable,  VariableExpression var)
        {
            List<string> outp = new List<string>();
            if (!symbolTable.ContainsKey(var.Name))
                throw new SyntaxErrorException("value does not exists",new Token());
            int val = symbolTable[var.Name];
            outp.Add("@" + val);
            outp.Add("D=A");
            outp.Add("@LCL");
            outp.Add("D=M+D");
            outp.Add("A=D");
            outp.Add("D=M");
            outp.Add("@RESULT");
            outp.Add("M=D");
            return outp;
        }
        private List<string> GenBin(Dictionary<string, int> symbolTable, BinaryOperationExpression var)
        {
            List<string> outp = new List<string>();
            Expression op1 = var.Operand1;
            outp.AddRange(GenExp(symbolTable, op1));
            outp.Add("@RESULT");
            outp.Add("D=M");
            outp.Add("@OPERAND1");
            outp.Add("M=D");
            Expression op2 = var.Operand2;
            outp.AddRange(GenExp(symbolTable, op2));
            outp.Add("@RESULT");
            outp.Add("D=M");
            outp.Add("@OPERAND2");
            outp.Add("M=D");
            outp.Add("@OPERAND1");
            outp.Add("D=M");
            outp.Add("@OPERAND2");
            string tav = var.Operator;
            outp.Add("D=D"+tav+"M");
            outp.Add("@RESULT");
            outp.Add("M=D");
            return outp;
        }
        private List<string> GenExp(Dictionary<string, int> symbolTable,Expression var)
        {
            List<string> outp = new List<string>();
            if (isNumber(var))
            {
                    outp.AddRange(GenNumber(symbolTable, (NumericExpression)var));
            }
            else if (var is VariableExpression)
            {
                    outp.AddRange(GenVar(symbolTable, (VariableExpression)var));
            }
            return outp;
        }
        public Dictionary<string, int> ComputeSymbolTable(List<VarDeclaration> lDeclerations)
        {
            Dictionary<string, int> dTable = new Dictionary<string, int>();
            int index = 0;
            foreach(VarDeclaration var in lDeclerations)
            {
                if(!var.Name.StartsWith("_"))
                {
                    if (dTable.ContainsKey(var.Name))
                        throw new SyntaxErrorException("Var decleration table already cantains the var name ",new Token());
                    dTable.Add(var.Name,index);
                    index++;
                }
            }
            foreach (VarDeclaration var in lDeclerations)
            {
                if (var.Name.StartsWith("_") && char.IsDigit(var.Name.ElementAt(1)))
                {
                    if (dTable.ContainsKey(var.Name))
                        throw new SyntaxErrorException("Var decleration table already cantains the var name ", new Token());
                    dTable.Add(var.Name, index);
                    index++;
                }
                else if (!dTable.ContainsKey(var.Name))
                    throw new SyntaxErrorException("Var decleration table already cantains the var name ", new Token());
            }
            return dTable;
        }


        public List<string> GenerateCode(List<LetStatement> lSimpleAssignments, List<VarDeclaration> lVars)
        {
            List<string> lAssembly = new List<string>();
            Dictionary<string, int> dSymbolTable = ComputeSymbolTable(lVars);
            foreach (LetStatement aSimple in lSimpleAssignments)
                lAssembly.AddRange(GenerateCode(aSimple, dSymbolTable));
            return lAssembly;
        }

        public List<LetStatement> SimplifyExpressions(LetStatement s, List<VarDeclaration> lVars)
        {
            //add here code to simply expressins in a statement. 
            //add var declarations for artificial variables.
            if (s.Value is BinaryOperationExpression)
            {
                LetStatement let1 = new LetStatement();
                let1.Variable ="_" + place;
                place++;
                let1.Value = ((BinaryOperationExpression)s.Value).Operand1;
                LetStatement let2 = new LetStatement();
                let2.Variable = "_" + place;
                place++;
                let2.Value = ((BinaryOperationExpression)s.Value).Operand2;
                VarDeclaration var1 = new VarDeclaration("int", let1.Variable);
                VarDeclaration var2 = new VarDeclaration("int", let2.Variable);
                lVars.Add(var1);
                lVars.Add(var2);
                List<LetStatement> state = new List<LetStatement>();
                state.AddRange(SimplifyExpressions(let1, lVars));
                state.AddRange(SimplifyExpressions(let2, lVars));
                LetStatement let3 = new LetStatement();
                let3.Variable =s.Variable;
                let3.Value = new BinaryOperationExpression();
                ((BinaryOperationExpression)let3.Value).Operand1 = new VariableExpression();
                ((VariableExpression)((BinaryOperationExpression)let3.Value).Operand1).Name = let1.Variable;
                ((BinaryOperationExpression)let3.Value).Operand2 = new VariableExpression();
                ((VariableExpression)((BinaryOperationExpression)let3.Value).Operand2).Name = let2.Variable;
                ((BinaryOperationExpression)let3.Value).Operator = ((BinaryOperationExpression)s.Value).Operator;
                state.Add(let3);
                return state;

            }
            else
            {
                List<LetStatement> lis = new List<LetStatement>();
                lis.Add(s);
                return lis;
            }
        }
        public List<LetStatement> SimplifyExpressions(List<LetStatement> ls, List<VarDeclaration> lVars)
        {
            List<LetStatement> lSimplified = new List<LetStatement>();
            foreach (LetStatement s in ls)
                lSimplified.AddRange(SimplifyExpressions(s, lVars));
            return lSimplified;
        }


        public LetStatement ParseStatement(List<Token> lTokens)
        {
            TokensStack sTokens = new TokensStack();
            for (int i = lTokens.Count - 1; i >= 0; i--)
                sTokens.Push(lTokens[i]);
            LetStatement s = new LetStatement();
            s.Parse(sTokens);
            return s;
        }


        public List<Token> Tokenize(string sLine, int iLine)
        {
            //insert here code from assignment 3.1 to tokenize a single line
            List<Token> lTokens = new List<Token>();
            string opt = "";
           for(int i = 0; i < sLine.Length; i++)
            {
                if (sLine.ElementAt(i) == ' ')
                    continue;
                opt += sLine.ElementAt(i);
                Token t = makeToken(opt,iLine,i - opt.Length);
                if (t != null)
                {
                    lTokens.Add(t);
                    opt = "";

                }
                else
                {
                    Token tok = charToken(sLine.ElementAt(i), iLine, i);
                    if (tok != null)
                    {   
                        opt = opt.Substring(0, opt.Length - 1);
                        if (int.TryParse(opt, out int ret))
                        {
                            lTokens.Add(new Number(ret.ToString(), iLine, i - opt.Length));
                        }
                        else
                        {
                            lTokens.Add(new Identifier(opt, iLine, i - opt.Length));
                        }
                        lTokens.Add(tok);
                        opt = "";
                    }
                }
            }
            if (!string.IsNullOrEmpty(opt))
                throw new SyntaxErrorException("wrong syntax",new Token() );
            return lTokens;
        }
        private Token makeToken(string str, int line, int position)
        {
            if (Token.Constants.Contains(str))
                return new Constant(str, line, position);
            else if (Token.VarTypes.Contains(str))
                return new VarType(str, line, position);
            else if (Token.Statements.Contains(str))
                return new Statement(str, line, position);
            else if (str.Length > 1)
                return null;
            else
            {
                char ch = str.ElementAt(0);
                if (Token.Operators.Contains(ch))
                    return new Operator(ch, line, position);
                else if (Token.Parentheses.Contains(ch))
                    return new Parentheses(ch, line, position);
                else if (Token.Separators.Contains(ch))
                    return new Separator(ch, line, position);
                else return null;
            }
        }
        private Token charToken(char tok, int line, int position)
        {
            if (Token.Operators.Contains(tok))
                return new Operator(tok, line, position);
            else if (Token.Parentheses.Contains(tok))
                return new Parentheses(tok, line, position);
            else if (Token.Separators.Contains(tok))
                return new Separator(tok, line, position);
            else return null;
        }
        private bool isLegalID(string str)
        {
            if (string.IsNullOrEmpty(str) | string.IsNullOrWhiteSpace(str))
                return false;
            else if (!char.IsLetter(str.ElementAt(0))&&str.ElementAt(0)!='_')
                return false;
            else return true;
        }
        private bool isNumber(string str)
        {
            return int.TryParse(str, out int ret);
        }
        private List<string> Split(string s, char[] aDelimiters)
        {
            List<string> lTokens = new List<string>();
            while (s.Length > 0)
            {
                string sToken = "";
                int i = 0;
                for (i = 0; i < s.Length; i++)
                {
                    if (aDelimiters.Contains(s[i]))
                    {
                        if (sToken.Length > 0)
                            lTokens.Add(sToken);
                        lTokens.Add(s[i] + "");
                        break;
                    }
                    else
                        sToken += s[i];
                }
                if (i == s.Length)
                {
                    lTokens.Add(sToken);
                    s = "";
                }
                else
                    s = s.Substring(i + 1);
            }
            return lTokens;
        }

        public List<Token> Tokenize(List<string> lCodeLines)
        {
            List<Token> lTokens = new List<Token>();
            for (int i = 0; i < lCodeLines.Count; i++)
            {
                string sLine = lCodeLines[i];
                List<Token> lLineTokens = Tokenize(sLine, i);
                lTokens.AddRange(lLineTokens);
            }
            return lTokens;
        }

    }
}
